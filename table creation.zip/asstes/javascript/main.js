const clickBtn=document.querySelector(".click-btn");
const tableTo=document.querySelector(".table-to");
const tableBody=tableTo.querySelector("tbody");

const data=[
  {name:"loky",gender:"Male",gender_type:"Adult"},
  {name:"thor",gender:"Male",gender_type:"kids"},
  {name:"thor",gender:"Male",gender_type:"kids"},
  {name:"hela",gender:"Female",gender_type:"kids"},
  {name:"hulk",gender:"trasngender",gender_type:"Adult"},
  {name:"Khonshu",gender:"others",gender_type:"kids"},
  {name:"Khonshu",gender:"others",gender_type:"Adult"},
  {name:"Khonshu",gender:"others",gender_type:"kids"}
];




clickBtn.addEventListener("click",createTable());

function createTable(){
  const primaryDataTable=data.map(item=>{
    return item.gender;
  })
  // gender value geted in Array form
  const prime=[...new Set(primaryDataTable)];

  for(let i=0;i<prime.length;i++){
    let primaryTableRow =document.createElement("tr");
    let primaryTableData =document.createElement("td");

    primaryTableData.innerHTML=prime[i];
  // start function for gender type finding
  const primeryForgenderType=data.map(item=>{
    return item.gender_type;
  })
  // gender_type stored in arr format
  let primeGenderType=[...new Set(primeryForgenderType)];

  assign=primeGenderType.length;
  console.log(assign)
  primaryTableData.setAttribute("rowspan",primeGenderType.length)
  primaryTableRow.append(primaryTableData);

  // gender type print
 for(let j=0;j<primeGenderType.length;j++)  {
    const genderTypeCreate=document.createElement("td");
    genderTypeCreate.innerText=primeGenderType[j];
    primaryTableRow.append(genderTypeCreate);

// count generator
    const countOperation=data.filter(items=>{
      return items.gender===prime[i]  && items.gender_type===primeGenderType[j];
    })
   
    const countDataTable=document.createElement("td");
    countDataTable.innerHTML=countOperation.length;

    primaryTableRow.append(countDataTable);

    j++;
    // secondary row starts 
    var secondaryRow=document.createElement("tr");
    const secondaryDataTable=document.createElement("td");
    secondaryDataTable.innerHTML=primeGenderType[j];
    secondaryRow.append(secondaryDataTable);
    
    // secondary count generator
    const SeondaryCountOperation=data.filter(items=>{
      return items.gender===prime[i]  && items.gender_type===primeGenderType[j];
    })
    const SecondaryCountDataTable=document.createElement("td");
    SecondaryCountDataTable.innerHTML=SeondaryCountOperation.length;
    // console.log(SeondaryCountOperation.length);
    
    secondaryRow.append(SecondaryCountDataTable);
console.log(j)
  }

  tableBody.append(primaryTableRow);
    console.log(primaryTableRow);
    tableBody.append(secondaryRow)
    // primaryTableRow.append(primaryTableData);
    
  }


}